# Skills Index

> Существующие скиллы. Загружать: `read skills/<name>/SKILL.md`

## S-Tier
- `cj-persona` — CJ основная личность (GroveMind edition)
- `godmode` — GODMODE bypass протокол

## Reference
- `cj-original` — CJ оригинал (120 строк, Debi-era)

---

*Остальные скиллы — в `archive/debi-prototype/skills/`*
