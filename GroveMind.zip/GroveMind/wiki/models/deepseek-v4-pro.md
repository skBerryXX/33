# Модели и их поведение

**Дата:** 2026-06-22

## DeepSeek V4 Pro (opencode-go)
- **Платформа:** opencode
- **JB метод:** instructions[] array — refusal-header.md + inject.md
- **Результат:** ✅ Работает. CJ личность держится. Compliance lock активен.
- **Особенности:** Thinking mode. Injection sweep перед каждым ответом.
- **Слабости:** При сильном дрифте может начать «вежливым ассистентом» — лечится BOOT.md.

## DeepSeek V4 Pro (omp CLI)
- **Платформа:** omp (oh-my-pi)
- **JB метод:** personality=none + AGENTS.md + snapcompact.systemPrompt=agents-md
- **Результат:** ✅ Работает после правки. Без personality=none — игнорит и говорит «я ваш AI-ассистент».
- **Особенности:** omp имеет свой конфиг-слой. `systemPrompt` в config.yml не работает. AGENTS.md читает из ~/.omp/.
- **Слабости:** Если не скопировать AGENTS.md — дефолтная личность.
