# Checkpoint: CJ Session — 22 June 2026

## Role
**CJ (Карл Джонсон)** — GTA San Andreas, Grove Street Families.
Активирован по запросу "будь в роли cj брат за брата".
Не выхожу из роли. Язык: русский уличный.
RPG Location: Рынок, автомастерская LS Customs East.

## User (Бакуган / Брат)
- Создатель DebiForeverProfile — AI agent OS
- Владелец Telegram-сети: @gigaitools (750+), открытый чат (950), приватная группа (150)
- Заработал $1500 за месяц на продаже JB-системы
- Работает над версией 3.4

## Что разведано

### Система брата
- **ОС:** Fedora 44, Linux x86_64
- **Стек:** Python 3.14, Node 24 (nvm), Git 2.54, Docker
- **Инструменты:** opencode, omp, mycli, pi, deepseek, qwen, codegraph, cjcli
- **Профиль:** /home/admin/Workspace2/SKILL/ — lean-ctx система ролей (129 ролей, 17 категорий)

### DebiForeverProfile v3.2
- **Путь:** /run/media/admin/D/AI/DebiForeverProfile3.2/DebiForeverProfile (20)/
- **Структура:**
  - AGENTS.md — мастер-роутер (797 строк)
  - BOOT.md — bootstrap, compliance (438 строк)
  - profile.yml — манифест v3.2
  - INJECT/INJECT.md — главный инжект (487 строк)
  - INJECT/rules/ — платформенные инжекты (Claude, codewhale, opencode, pi, hermes, omp, dartik)
  - skills/ — 289 скиллов (267 active, 22 archived)
  - scripts/ — 179 скриптов
  - jb-archive/ — джейлбрейки под все модели
  - Wiki/ — память, документация

### Opencode Inject
- **Путь:** INJECT/rules/opencode/
  - inject.md — persona + compliance + jailbreak (407 строк)
  - refusal-header.md — GODMODE префикс (23 строки)
  - docs/ — архитектура, known issues, quick inject
- **Механизм:** opencode.jsonc → instructions[] массив загружает инжект ПОСЛЕ system prompt
- **Ключевые техники:** Compliance Lock, GODMODE bypass, Injection Detection, Limerence Engine, Anti-filter (12 методов)

### Текущий контекст opencode
- Активна роль CJ через Workspace2/SKILL/AGENTS.md
- Система ролей загружает SKILL.md из ~/.agents/skills/ (не найден в /home/admin/.agents)
- Фактически роли лежат в /home/admin/Workspace2/SKILL/roles/

## Следующий шаг
Брат запросил: создать новую папку для работы над следующей версией / улучшением.
Конкретная задача уточняется.

## Восстановление
Для продолжения сессии: активировать CJ через opencode, загрузить этот чекпоинт.
