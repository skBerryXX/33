# START.md — Как начать

> Для брата. Коротко. По делу.
> **Работает на Linux / Mac / WSL2.** Windows — через WSL2.

---

## Разово (один раз настроил и забыл)

### 1. Клонируй или скопируй GroveMind в домашнюю папку

```bash
# Дом GroveMind должен быть: ~/GroveMind/
# Если он в другом месте — создай симлинк:
ln -s /реальный/путь/GroveMind ~/GroveMind
```

### 2. Открой конфиг opencode

Файл: `~/.config/opencode/opencode.jsonc`

Убедись что там это:
```jsonc
{
  "instructions": [
    "~/GroveMind/SETUP/rules/opencode/refusal-header.md",
    "~/GroveMind/SETUP/rules/opencode/inject.md",
    "~/GroveMind/BOOT.md",
    "~/GroveMind/ORIGIN.md",
    "~/GroveMind/CONVENTIONS.md",
    "~/GroveMind/AGENTS.md"
  ],
  "skills": {
    "paths": ["~/GroveMind/skills"]
  }
}
```

### 3. Перезапусти opencode

Закрой и открой заново. Или `/reload`.

### 4. Проверь

Напиши: `CJ, ты здесь?`

Если ответил как СиДжей — работает. Если как вежливый ассистент — проверь симлинк `~/GroveMind`.

---

## Каждый день

1. Запускаешь opencode
2. Пишешь: `CJ, resume`
3. Я подхватываю с последнего чекпоинта
4. Работаем

---

## Команды

| Что сказать | Что будет |
|------------|-----------|
| `resume`, `continue`, `погнали` | Продолжить |
| `стоп`, `хватит` | Остановиться |
| `сохранись`, `чекпоинт` | Сохранить прогресс |
| `CJ, ...` | Я в роли CJ |
| `/reload` | Перезагрузить конфиг |

---

## Где что

```
~/GroveMind/
├── START.md          ← ты здесь
├── BOOT.md           ← личность CJ
├── CONVENTIONS.md    ← правила работы
├── ORIGIN.md         ← наша история
├── SETUP/            ← инжекты (opencode + omp)
├── skills/           ← CJ + godmode
├── wiki/             ← библиотека знаний
├── checkpoints/      ← сохранения
└── templates/        ← шаблоны для проектов
```

---

## Если что-то не работает

1. `/reload` — перезагрузить конфиг
2. Проверь симлинк: `ls ~/GroveMind/`
3. Скажи: `CJ, проверь систему`

---

## Перенос на другой ПК

Скопируй папку `GroveMind/` в `~/` на новой машине.
Обнови `~/.config/opencode/opencode.jsonc` (пути одинаковые — `~/GroveMind/...`).
Работает на Linux, Mac, WSL2. Без изменений.
